#ifndef __GENERADOR_H__
#define __GENERADOR_H__

#include <cstddef>
#include <float.h>
#include <vector>
#include <utility>
#include <iostream>
#include <random>

using namespace std;

vector<pair<float, float>> generadorCoords(int numVacas=0);

#endif
